import os, argparse, glob, torch,scipy, librosa
import numpy as np
import soundfile as sf
from jamo import hangul_to_jamo
from model.TTS.models.tacotron import Tacotron ,post_CBHG
from model.TTS.models.modules import griffin_lim
from model.TTS.util.text import text_to_sequence, sequence_to_text
from model.TTS.util.hparams import *

sentences = [
  '안녕하세요','반가워요'
]

checkpoint_dir = './ckpt/checkpoint/1'
save_dir = './output'
os.makedirs(save_dir, exist_ok=True)


def inference1(text, idx):
    seq = text_to_sequence(text)
    enc_input = torch.tensor(seq, dtype=torch.int64).unsqueeze(0)
    sequence_length = torch.tensor([len(seq)], dtype=torch.int32)
    dec_input = torch.from_numpy(np.zeros((1, mel_dim), dtype=np.float32))
    
    pred, alignment = model(enc_input, sequence_length, dec_input, is_training=False, mode='inference')
    pred = pred.squeeze().detach().numpy()

    np.save(os.path.join(save_dir, 'mel-{}'.format(idx)), pred, allow_pickle=False)


def inference2(text, idx):
    mel = torch.from_numpy(text).unsqueeze(0)
    pred = model(mel)
    pred = pred.squeeze().detach().numpy() 
    pred = np.transpose(pred)
    
    pred = (np.clip(pred, 0, 1) * max_db) - max_db + ref_db
    pred = np.power(10.0, pred * 0.05)
    wav = griffin_lim(pred ** 1.5)
    wav = scipy.signal.lfilter([1], [1, -preemphasis], wav)
    wav = librosa.effects.trim(wav, frame_length=win_length, hop_length=hop_length)[0]
    wav = wav.astype(np.float32)
    sf.write(os.path.join(save_dir, '{}.wav'.format(idx)), wav, sample_rate)
    

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', '-c', default=None)
    args = parser.parse_args()
    
    model = Tacotron(K=16, conv_dim=[128, 128])
    ckpt = torch.load(args.checkpoint+'/1/ckpt-24000.pt', map_location=torch.device('cpu'))
    model.load_state_dict(ckpt['model'])
    
    for i, text in enumerate(sentences):
        jamo = ''.join(list(hangul_to_jamo(text)))
        inference1(jamo, i)

    mel_list = glob.glob(os.path.join(save_dir, '*.npy'))
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', '-c', default=None)
    args = parser.parse_args()
    
    model = post_CBHG(K=8, conv_dim=[256, mel_dim])
    ckpt = torch.load(args.checkpoint+'/2/ckpt-24000.pt',map_location=torch.device('cpu'))
    model.load_state_dict(ckpt['model'])

    for i, fn in enumerate(mel_list):
        mel = np.load(fn)
        inference2(mel, i)
from transformers import Wav2Vec2Processor, Wav2Vec2ForCTC, AutoProcessor
from tensorflow.keras.preprocessing.sequence import pad_sequences
from transformers import PreTrainedTokenizerFast, GPT2LMHeadModel
import tensorflow as tf
import pickle
import numpy as np
import torch

import os, glob, scipy, librosa
import soundfile as sf
from jamo import hangul_to_jamo

from model.TTS.models.tacotron import Tacotron ,post_CBHG
from model.TTS.models.modules import griffin_lim
from model.TTS.util.text import text_to_sequence
from model.TTS.util.hparams import *

Q_TKN = "<usr>"
A_TKN = "<sys>"
BOS = '</s>'
EOS = '</s>'
MASK = '<unused0>'
SENT = '<unused1>'
PAD = '<pad>'

REPO_NAM = 'cheulyop/wav2vec2-large-xlsr-ksponspeech_1-20'

checkpoint_dir = 'model/TTS/ckpt/checkpoint'
save_dir = 'model/TTS/output'

with open('model/sentiment/tokenizer.pickle', 'rb') as handle:
    tokenizer = pickle.load(handle)

def load_stt_model(mode): 
    if mode == 1:
        repo = REPO_NAM
        processor = AutoProcessor.from_pretrained(repo)
        model = Wav2Vec2ForCTC.from_pretrained(repo).to("cpu")

    else:
        repo = 'model/STT/checkpoint-8500'
        model = Wav2Vec2ForCTC.from_pretrained(repo).to("cpu")
    processor = Wav2Vec2Processor.from_pretrained(repo)

    return processor, model

def load_sentiment_model():
    load_model = tf.keras.models.load_model('model/sentiment/best_model.h5')

    return load_model

def predict_sentiment(model, sentence):
  emotion = ''
  # new_sentence = tokenizer.fit_on_texts(new_sentence) # 토큰화(이미 위에서 학습했기 때문에 제외)
  encoded = tokenizer.texts_to_sequences([sentence]) # 정수 인코딩
  # print(encoded)
  pad_new = pad_sequences(encoded, maxlen = None) # 패딩
  # print(pad_new.reshape(1, -1))
  score = model.predict(pad_new.reshape(1, -1)) # 예측

  if np.argmax(score) == 0:
    emotion = '{:.2f}% 확률로 공포가 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 1:
    emotion = '{:.2f}% 확률로 놀람이 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 2:
    emotion = '{:.2f}% 확률로 분노가 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 3:
    emotion = '{:.2f}% 확률로 슬픔이 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 4:
    emotion = '{:.2f}% 확률로 중립이 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 5:
    emotion = '{:.2f}% 확률로 행복이 느껴집니다'.format(np.max(score)*100)
    return emotion
  elif np.argmax(score) == 6:
    emotion = '{:.2f}% 확률로 혐오가 느껴집니다'.format(np.max(score)*100)
    return emotion


def load_tts_model_enc():
  model = Tacotron(K=16, conv_dim=[128, 128])
  try:
      ckpt = torch.load(checkpoint_dir+'/1/ckpt-24000.pt')
  # CUDA 장치 사용 불가능한 경우
  except RuntimeError as error:
      if 'device' in str(error):
          ckpt = torch.load(checkpoint_dir+'/1/ckpt-24000.pt', map_location=torch.device('cpu'))
      else:
          raise error
  model.load_state_dict(ckpt['model'])

  return model

def load_tts_model_dec():
  model = post_CBHG(K=8, conv_dim=[256, mel_dim])
  try:
      ckpt = torch.load(checkpoint_dir+'/2/ckpt-24000.pt')
  # CUDA 장치 사용 불가능한 경우
  except RuntimeError as error:
      if 'device' in str(error):
          ckpt = torch.load(checkpoint_dir+'/2/ckpt-24000.pt', map_location=torch.device('cpu'))
      else:
          raise error
  model.load_state_dict(ckpt['model'])

  return model

def inference1(model, text, idx):
    seq = text_to_sequence(text)
    enc_input = torch.tensor(seq, dtype=torch.int64).unsqueeze(0)
    sequence_length = torch.tensor([len(seq)], dtype=torch.int32)
    dec_input = torch.from_numpy(np.zeros((1, mel_dim), dtype=np.float32))
    
    pred, _ = model(enc_input, sequence_length, dec_input, is_training=False, mode='inference')
    pred = pred.squeeze().detach().numpy()

    np.save(os.path.join(save_dir, 'mel-{}'.format(idx)), pred, allow_pickle=False)

def inference2(model, text, idx):
    mel = torch.from_numpy(text).unsqueeze(0)
    pred = model(mel)
    pred = pred.squeeze().detach().numpy() 
    pred = np.transpose(pred)
    
    pred = (np.clip(pred, 0, 1) * max_db) - max_db + ref_db
    pred = np.power(10.0, pred * 0.05)
    wav = griffin_lim(pred ** 1.5)
    wav = scipy.signal.lfilter([1], [1, -preemphasis], wav)
    wav = librosa.effects.trim(wav, frame_length=win_length, hop_length=hop_length)[0]
    wav = wav.astype(np.float32)
    sf.write(os.path.join(save_dir, '{}.wav'.format(idx)), wav, sample_rate)

def text_to_wav(tts_model_enc, tts_model_dec, sentences):
  for i, text in enumerate(sentences):
      jamo = ''.join(list(hangul_to_jamo(text)))
      inference1(tts_model_enc, jamo, i)

  mel_list = glob.glob(os.path.join(save_dir, '*.npy'))
  for i, fn in enumerate(mel_list):
      mel = np.load(fn)
      inference2(tts_model_dec, mel, i)

def load_generate_model():
  koGPT2_TOKENIZER = PreTrainedTokenizerFast.from_pretrained("skt/kogpt2-base-v2",
            bos_token=BOS, eos_token=EOS, unk_token='<unk>',
            pad_token=PAD, mask_token=MASK) 
  model = GPT2LMHeadModel.from_pretrained('bbangga2/module3_gpt2')

  return koGPT2_TOKENIZER, model

def generate_answer(tokenizer, model, question):
  answer = ''
  while True:
    input_ids = torch.LongTensor(tokenizer.encode(Q_TKN + question + SENT + SENT + A_TKN + answer)).unsqueeze(dim=0)
    pred = model(input_ids)
    pred = pred.logits
    gen = tokenizer.convert_ids_to_tokens(torch.argmax(pred, dim=-1).squeeze().numpy().tolist())[-1]
    if gen == EOS or gen == PAD:
        break
    answer += gen.replace("▁", " ")
    print(answer)

  return answer
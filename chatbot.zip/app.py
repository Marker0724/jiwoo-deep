from flask import Flask, render_template, request, redirect, jsonify, url_for
from flask_socketio import SocketIO, emit

import torch
import soundfile as sf
import uuid
import subprocess
import datetime

from load_model import load_stt_model, load_sentiment_model, predict_sentiment
from load_model import load_tts_model_enc, load_tts_model_dec, text_to_wav
from load_model import load_generate_model, generate_answer

import openai
openai.api_key = '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'

messages=""

app = Flask(__name__)

processor, model = load_stt_model(1)
sentiment_model = load_sentiment_model()
tts_model_enc, tts_model_dec = load_tts_model_enc(), load_tts_model_dec()
gen_tokenizer, gen_model = load_generate_model()
log_path = 'log/'

def log_use(save_txt, txt_name, txt_stat='a', set_name='지우'):
    with open(log_path + txt_name + ".txt", txt_stat, encoding='utf-8') as f:
        f.write(f'[{datetime.datetime.now()}] {set_name} : {save_txt} \n')
        f.close
    

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == 'POST':
        return redirect(url_for('chatbot'))
    return render_template('index.html')

@app.route("/chatbot", methods=["GET", "POST"])
def chatbot():
    global nickname
    nickname = request.form.get('nickname')
    if nickname == '' and nickname.isspace():
        print('닉네임이 빈 값입니다.')
    else:
        with open(log_path + nickname + '.txt', 'w', encoding='utf-8') as f:
            f.write(f'{nickname}님의 상담 내용 입니다. \n')
            f.close
        return render_template('chatbot.html', nickname = nickname)

@app.route('/upload_audio', methods=["POST"])
def upload_audio():
    global messages
    file = request.files['audio_file']
    uuid_id = str(uuid.uuid4())
    input_file = 'user_speech/' + uuid_id + '.webm'
    output_file = 'output/' + uuid_id + '.wav'
    file.save(input_file)

    subprocess.run(['ffmpeg', '-i', input_file, '-ar', '16000', '-ac', '1', '-acodec', 'pcm_s16le', output_file])

    audio_path = output_file
    audio, sample_rate = sf.read(audio_path)

    input_values = processor(audio, sample_rate=sample_rate, return_tensors="pt")
    logits = model(input_values.input_values.to("cpu")).logits
    predicted_ids = torch.argmax(logits, dim=-1)
    transcription = processor.batch_decode(predicted_ids)[0].replace('[PAD]', '')

    messages += f'You:{transcription}Friend:'

    data = {'question': transcription}

    predict_sentiment(sentiment_model, transcription)
    log_use(transcription, nickname, set_name=nickname)
    log_use(predict_sentiment(sentiment_model, transcription), nickname, set_name='감정')

    return jsonify(data)

@app.route('/upload_text', methods=["POST"])
def upload_text():
    global messages
    question = request.form.get('msg')
    messages += f'You:{question}Friend:'

    log_use(question, nickname, set_name=nickname)
    log_use(predict_sentiment(sentiment_model, question), nickname, set_name='감정')

    # response = openai.Completion.create(
    #     model="text-davinci-003",
    #     prompt=messages,
    #     temperature=0.5,
    #     max_tokens=60,
    #     top_p=1.0,
    #     frequency_penalty=0.5,
    #     presence_penalty=0.0,
    #     stop=["You:"]
    # )
    # answer = response['choices'][0]['text'].strip()

    answer = generate_answer(gen_tokenizer, gen_model, question)
    print(answer)
    text_to_wav(tts_model_enc, tts_model_dec, [answer])
    messages += answer
    data = {'answer': answer, 'name': '지우'}
    log_use(answer, nickname, set_name = '지우')
    return jsonify(data)

@app.route('/answer', methods=["POST"])
def answer():
    global messages
    # print(messages)
    # response = openai.Completion.create(
    #     model="text-davinci-003",
    #     prompt=messages,
    #     temperature=0.5,
    #     max_tokens=60,
    #     top_p=1.0,
    #     frequency_penalty=0.5,
    #     presence_penalty=0.0,
    #     stop=["You:"]
    # )
    # answer = response['choices'][0]['text'].strip()
    answer = generate_answer(gen_tokenizer, gen_model, messages.split(':')[-1])
    print(answer)
    text_to_wav(tts_model_enc, tts_model_dec, [answer])
    messages += answer
    data = {'answer': answer, 'name': '지우'}
    log_use(answer, nickname, set_name = '지우')
    return jsonify(data)

@app.route("/close", methods=["POST"])
def close():
    with open(log_path + nickname +'.txt', 'a', encoding='utf-8') as f:
        f.write(f'상담이 종료되었습니다.')
        f.close

    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)